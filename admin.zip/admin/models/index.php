<?php if($_settings->chk_flashdata('success')): ?>
<script>
	alert_toast("<?php echo $_settings->flashdata('success') ?>",'success')
</script>
<?php endif;?>
<style>
	.model-thumbnail{
		width:3em;
		height:3em;
		object-fit:cover;
		object-position:center center;
	}
	th{
		text-align:center;
	}
</style>
<div class="card card-outline rounded-0 card-navy">
	<div class="card-header">
		<h3 class="card-title"><b>Tampilkan Model Mobil</b></h3>
		<div class="card-tools">
			<a href="./?page=models/manage_model" id="create_new" class="btn btn-flat btn-sm btn-primary"><span class="fas fa-plus"></span> Tambah Model Baru</a>
		</div>
	</div>
	<div class="card-body">
        <div class="container-fluid">
			<table class="table table-hover table-striped table-bordered" id="list">
				<colgroup>
					<col width="5%">
					<col width="20%">
					<col width="25%">
					<col width="25%">
					<col width="10%">
					<col width="10%">
				</colgroup>
				<thead>
					<tr>
						<th>No</th>
						<th>Tanggal Masuk</th>
						<th>Merek/Tipe</th>
						<th>Model</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					$i = 1;
						$qry = $conn->query("SELECT m.*, b.name as `brand`, ct.name as `car_type` from `model_list` m inner join brand_list b on m.brand_id = b.id inner join car_type_list ct on m.car_type_id = ct.id where m.delete_flag = 0 order by b.`name` asc, m.`model` asc ");
						while($row = $qry->fetch_assoc()):
					?>
						<tr>
							<td class="text-center"><?php echo $i++; ?></td>
							<td><?php echo date("Y-m-d H:i",strtotime($row['date_created'])) ?></td>
							
							<td class="">
								<div style="line-height:1em">
									<div><b><?= $row['brand'] ?></b></div>
									<div><small class="text-muted"><?= $row['car_type'] ?></small></div>
								</div>
							</td>
							<td class=""><?= $row['model'] ?></td>
							<td class="text-center">
                                <?php if($row['status'] == 1): ?>
                                    <span class="badge badge-success px-3 rounded-pill">Aktif</span>
                                <?php else: ?>
                                    <span class="badge badge-danger px-3 rounded-pill">Tidak Aktif</span>
                                <?php endif; ?>
                            </td>
							<td align="center">
								 <button type="button" class="btn btn-flat p-1 btn-default btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
				                  		Action
				                    <span class="sr-only">Toggle Dropdown</span>
				                  </button>
				                  <div class="dropdown-menu" role="menu">
				                    <a class="dropdown-item" href="./?page=models/view_model&id=<?php echo $row['id'] ?>"><span class="fa fa-eye text-dark"></span> Lihat Data</a>
				                    <div class="dropdown-divider"></div>
				                    <a class="dropdown-item" href="./?page=models/manage_model&id=<?php echo $row['id'] ?>"><span class="fa fa-edit text-primary"></span> Edit</a>
				                    <div class="dropdown-divider"></div>
				                    <a class="dropdown-item delete_data" href="javascript:void(0)" data-id="<?php echo $row['id'] ?>"><span class="fa fa-trash text-danger"></span> Hapus</a>
				                  </div>
							</td>
						</tr>
					<?php endwhile; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<script>
	$(document).ready(function(){
		$('.delete_data').click(function(){
			_conf("Are you sure to delete this model permanently?","delete_model",[$(this).attr('data-id')])
		})
		$('.table').dataTable({
			columnDefs: [
					{ orderable: false, targets: [5] }
			],
			order:[0,'asc']
		});
		$('.dataTable td,.dataTable th').addClass('py-1 px-2 align-middle')
	})
	function delete_model($id){
		start_loader();
		$.ajax({
			url:_base_url_+"classes/Master.php?f=delete_model",
			method:"POST",
			data:{id: $id},
			dataType:"json",
			error:err=>{
				console.log(err)
				alert_toast("An error occured.",'error');
				end_loader();
			},
			success:function(resp){
				if(typeof resp== 'object' && resp.status == 'success'){
					location.reload();
				}else{
					alert_toast("An error occured.",'error');
					end_loader();
				}
			}
		})
	}
</script>